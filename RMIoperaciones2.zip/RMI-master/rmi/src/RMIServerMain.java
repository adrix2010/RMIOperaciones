


public class RMIServerMain {

    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        try 
        {
            RMIService ws = new RMIService();
           
            int suma = ws.getSuma(133, 10);
            int resta = ws.getResta(10,5 );
            int multi = ws.getMulti(12,9);
            int div = ws.getDivision(6,3);
            int maximo = ws.getMaximo(12,50);
            int raiz = ws.getRaiz(25, 2);

            System.out.println("suma: " + suma); 
            System.out.println("resta" + resta);
            System.out.println("multiplicacion" + multi);
            System.out.println("division" + div);
            System.out.println("maximo" + maximo);
            System.out.println("raiz" + raiz);
        } 
        catch (Exception ex)
        {
            ex.printStackTrace();
            System.out.println("ERROR: " + ex);
        }
    }
}
