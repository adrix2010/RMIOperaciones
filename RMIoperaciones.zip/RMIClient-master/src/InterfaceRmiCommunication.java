


import java.rmi.*;

public interface InterfaceRmiCommunication extends Remote 
{
    Integer getSuma(int num1, int num2) throws RemoteException; 
    Integer getResta(int num1, int num2) throws RemoteException; 
    Integer getMulti(int num1, int num2) throws RemoteException;
    Integer getRaiz(int num1, int num2) throws RemoteException;
    Integer getMaximo(int num1, int num2) throws RemoteException;
    Integer getDivision(int num1, int num2) throws RemoteException;
    
}
