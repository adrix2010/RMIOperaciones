



public class RMIClientMain 
{
     public static void main(String[] args) 
    {
        try {
            RmiCommunicationClient wsc = new RmiCommunicationClient();

            int suma = wsc.getSuma(12, 1);
            int resta = wsc.getResta(10,5 );
            int multi = wsc.getMulti(12,9);
            int div = wsc.getDivision(6,3);
            int maximo = wsc.getMaximo(12,50);
            int raiz = wsc.getRaiz(25, 2);
            
             System.out.println(" resultado de la suma por el servidor: " + suma);
             System.out.println(" resultado de la resta por el servidor: " + resta);
             System.out.println(" resultado de la multiplicacion por el servidor: " + multi);
             System.out.println(" resultado de la division por el servidor: " + div);
             System.out.println(" resultado del maximo por el servidor: " + maximo);
             System.out.println(" resultado de la raiz por el servidor: " + raiz);
        } catch (Exception ex) {
            ex.printStackTrace();
             System.err.println("Connection error the server is not responding.");
        }
    }
}
